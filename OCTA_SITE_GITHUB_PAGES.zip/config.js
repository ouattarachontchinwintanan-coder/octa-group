window.OCTA_CONFIG = { contactEmail: "" }; // Insérer ici l’adresse professionnelle vérifiée.
